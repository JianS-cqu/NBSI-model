#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fit_fragility_curve.py
Refactored from `fit_fragility_curve_全国建筑群_V2++.py`

This script provides batch processing for fragility curve fitting
across multiple cities, structural types, seismic intensity levels,
and building functions.

Core functionalities:
- Read Excel outputs where each sheet corresponds to a given PGA level.
- Perform Probit regression (in log-Sa space) to estimate lognormal parameters.
- Export fitted fragility parameters (Excel), fragility curve plots (PNG),
  and scatter data for reproduction (CSV).
"""

from pathlib import Path
import argparse
import logging
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import norm
import statsmodels.api as sm
import os
import copy
import warnings

# ----- logging configuration -----
logger = logging.getLogger("fragility")
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
logger.addHandler(ch)


# ----- utility functions -----
def check_nan_in_result(result):
    """
    Check whether the statsmodels result contains NaN values
    in parameters, standard errors, p-values, or confidence intervals.

    Parameters
    ----------
    result : statsmodels.discrete.discrete_model.BinaryResults
        Fitted Probit model result.

    Returns
    -------
    bool
        True if the result is invalid (contains NaN or unexpected structure),
        False otherwise.
    """
    try:
        if np.any(np.isnan(result.params)):
            return True
        if np.any(np.isnan(result.bse)):
            return True
        if hasattr(result, "tvalues") and np.any(np.isnan(result.tvalues)):
            return True
        if hasattr(result, "pvalues") and np.any(np.isnan(result.pvalues)):
            return True
        if hasattr(result, "conf_int"):
            ci = result.conf_int()
            if np.any(np.isnan(ci)):
                return True
        return False
    except Exception:
        return True


def cal_fragility(Sa, num_gms, num_collapse, show_fig=False, plot_args=None):
    """
    Fit fragility parameters using Probit regression in log-Sa space.

    Parameters
    ----------
    Sa : array-like
        Ground motion intensity values (PGA, g).
    num_gms : array-like
        Number of ground motions at each Sa.
    num_collapse : array-like
        Number of exceedances (>= given damage state).
    show_fig : bool, optional
        If True, plot a diagnostic fragility curve.

    Returns
    -------
    mu_ln : float
        Mean of lognormal distribution in log-space.
    sigma_ln : float
        Standard deviation of lognormal distribution in log-space.
    """
    Sa = np.asarray(Sa, dtype=float)
    num_gms = np.asarray(num_gms, dtype=int)
    num_collapse = np.asarray(num_collapse, dtype=int)

    # Construct binary samples
    y = []
    X0 = []
    for i, sa in enumerate(Sa):
        ones = int(num_collapse[i])
        zeros = int(num_gms[i] - num_collapse[i])
        y.extend([1] * ones + [0] * zeros)
        X0.extend([sa] * (ones + zeros))

    y = np.array(y)
    X0 = np.array(X0, dtype=float)

    if len(np.unique(y)) < 2:
        return np.nan, np.nan

    try:
        X_log = np.log(X0)
        X_design = sm.add_constant(X_log)
        model = sm.Probit(y, X_design)
        result = model.fit(disp=False)
    except Exception:
        # Retry with perturbation and BFGS optimization
        eps = 1e-6
        rng = np.random.default_rng(seed=42)
        X_log = np.log(X0 + rng.normal(0, eps, size=X0.shape))
        X_design = sm.add_constant(X_log)
        model = sm.Probit(y, X_design)
        result = model.fit(disp=False, method="bfgs", maxiter=200)

    # Recheck with BFGS if invalid
    if check_nan_in_result(result):
        X_log = np.log(X0 + 1e-6)
        X_design = sm.add_constant(X_log)
        model = sm.Probit(y, X_design)
        result = model.fit(disp=False, method="bfgs", maxiter=200)

    b = result.params  # [intercept, slope]
    if abs(b[1]) < 1e-12:
        return np.nan, np.nan

    sigma_ln = 1.0 / b[1]
    mu_ln = -b[0] / b[1]

    if show_fig:
        Sa_fit = np.linspace(0.01, 2.0, 100)
        p_fit = norm.cdf(np.log(Sa_fit), mu_ln, sigma_ln)
        plt.figure()
        plt.plot(Sa_fit, p_fit, '-k', linewidth=2, label='fitted')
        obs = np.array(num_collapse) / np.array(num_gms, dtype=float)
        plt.scatter(Sa, obs, color='red', label='observed')
        plt.xlabel("PGA (g)")
        plt.ylabel("Probability")
        plt.legend()
        plt.grid(True)
        plt.show()
        plt.close()

    return float(mu_ln), float(sigma_ln)


def plot_fragility_curves(Sa_fit, p_list, path_save, save_name, Sa, damage_state_names,
                          num_collapse_stat, num_gms, show_state0=False, show_fig=False, save_scatter_value=True):
    """
    Plot and save fragility curves and observed scatter points.

    Parameters
    ----------
    Sa_fit : array
        PGA values for fitted curves.
    p_list : list of array
        Probabilities for each damage state.
    path_save : Path
        Directory for saving outputs.
    save_name : str
        Base name for output files.
    Sa : array
        Observed PGA levels.
    damage_state_names : list
        List of damage state identifiers.
    num_collapse_stat : array
        Number of exceedances per damage state.
    num_gms : array
        Number of ground motions at each Sa.
    """
    path_save = Path(path_save)
    path_save.mkdir(parents=True, exist_ok=True)
    figfile = path_save / f"{save_name}.png"

    plt.figure()
    colors = ['k','m','b','g','r']
    labels = ['DS1: none','DS2: slight','DS3: moderate','DS4: extensive','DS5: complete']
    for i, p in enumerate(p_list):
        if i == 0 and not show_state0:
            continue
        plt.plot(Sa_fit, p, '-', linewidth=2, label=labels[i])
    plt.xlabel('PGA (g)')
    plt.ylabel('Probability of exceedance')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(figfile)
    if show_fig:
        plt.show()
    plt.close()

    # Scatter plot and CSV export
    scatter_dir = path_save / (f"{save_name}_scatter")
    scatter_dir.mkdir(parents=True, exist_ok=True)
    plt.figure()
    for i, p in enumerate(p_list):
        if i == 0 and not show_state0:
            continue
        plt.plot(Sa_fit, p, '-', linewidth=2)
    num_sum = np.max(num_collapse_stat, axis=1)
    for idx in range(num_collapse_stat.shape[1]):
        plt.scatter(Sa, num_collapse_stat[:, idx] / num_sum, label=f"obs_{idx}")
    plt.xlabel('PGA (g)')
    plt.ylabel('Probability of exceedance')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    scatter_figfile = scatter_dir / f"{save_name}.png"
    plt.savefig(scatter_figfile)
    if show_fig:
        plt.show()
    plt.close()

    if save_scatter_value:
        df = pd.DataFrame({"Sa": Sa})
        for idx, name in enumerate(damage_state_names):
            df[name] = num_collapse_stat[:, idx] / np.max(num_collapse_stat, axis=1)
        df.to_csv(scatter_dir / f"{save_name}.csv", index=False)


def cal_accumulate_damageStateNum(damage_state_list, damage_num_split):
    """
    Compute cumulative exceedance counts for damage states.

    Parameters
    ----------
    damage_state_list : list
        Names of damage states.
    damage_num_split : array-like
        Count of observations per damage state.

    Returns
    -------
    damage_addup : array
        Cumulative exceedance counts (>= each damage state).
    total_count : int
        Total number of observations.
    """
    damage_num_split = np.asarray(damage_num_split, dtype=int)
    m = len(damage_num_split)
    damage_addup = np.zeros_like(damage_num_split)
    for i in range(m):
        damage_addup[i] = damage_num_split[i:].sum()
    return damage_addup, int(damage_num_split.sum())


def cal_p_collapse(Sa_fit, mu_ln, sigma_ln):
    """
    Compute exceedance probability based on lognormal parameters.

    Parameters
    ----------
    Sa_fit : array
        Input PGA values (log-transformed outside this function).
    mu_ln : float
        Lognormal mean (log-space).
    sigma_ln : float
        Lognormal standard deviation (log-space).

    Returns
    -------
    array
        Probability of exceedance.
    """
    if np.isnan(mu_ln) or np.isnan(sigma_ln) or (mu_ln == 0 and sigma_ln == 0):
        return np.zeros_like(Sa_fit)
    return norm.cdf(Sa_fit, mu_ln, sigma_ln)


# ----- main batch processing -----
def process_city(path_dir: Path, city: str, str_type_list, building_function_list, epa_list,
                 sf_list, rise_category_list, out_dir: Path, show_fig: bool = False):
    """
    Batch process fragility curve fitting for a given city.

    Parameters
    ----------
    path_dir : Path
        Root directory of input data (may contain per-city subfolders).
    city : str
        City code.
    str_type_list : list of str
        Structural type abbreviations, e.g., ['bc', 'rc', 'wd'].
    building_function_list : list of str
        Building function codes, e.g., ['r','b','p','i','o','x'].
    epa_list : list of str
        Effective peak acceleration (EPA) strings, e.g., ['0.05','0.1', ...].
    sf_list : list of float
        PGA values; each value corresponds to a sheet in the Excel input.
    rise_category_list : list of str
        Rise-category identifiers, e.g., ['h5'].
    out_dir : Path
        Root output directory. Results are written to out_dir / 'fragility_paras' / city.
    show_fig : bool, optional
        If True, display figures during processing. Default is False.
    """
    path_dir = Path(path_dir)
    out_dir = Path(out_dir)
    path_save = out_dir / "fragility_paras" / city
    path_save.mkdir(parents=True, exist_ok=True)

    exist_type = []
    fragility_paras_all = []

    for str_type in str_type_list:
        for building_function in building_function_list:
            for epa in epa_list:
                for rise_category in rise_category_list:
                    damage_csv_file = path_dir / (
                        f"damage_grade_total_count_city{{{city}}}"
                        f"_str_type_simple{{{str_type}}}"
                        f"_building_function{{{building_function}}}"
                        f"_epa{{{epa}}}"
                        f"_rise_category{{{rise_category}}}.xlsx"
                    )
                    # Fallback to a city subfolder if the file is not at the root.
                    if not damage_csv_file.exists():
                        damage_csv_file = path_dir / city / damage_csv_file.name

                    if not damage_csv_file.exists():
                        logger.debug(f"Missing file. Skipping: {damage_csv_file}")
                        continue
                    if damage_csv_file.stat().st_size == 0:
                        logger.debug(f"Empty file. Skipping: {damage_csv_file}")
                        continue

                    # Read each PGA sheet and collect cumulative exceedance counts.
                    damage_gather_sa = []
                    sa_readable = []
                    try:
                        for sa in sf_list:
                            sa_scale = f"grade_total_count_{sa}g"
                            # Source format: take rows 2–6 and cols 2–4 (iloc[1:6, 1:4])
                            df = (
                                pd.read_excel(damage_csv_file, sheet_name=sa_scale, header=None)
                                .iloc[1:6, 1:4]
                            )
                            df.columns = ['damage_grade', 'Number', 'Proportion']
                            damage_num_addup, damage_num_sum = cal_accumulate_damageStateNum(
                                np.asarray(df['damage_grade']),
                                np.asarray(df['Number'])
                            )
                            damage_gather_sa.append(damage_num_addup)
                            sa_readable.append(sa)
                    except Exception as e:
                        logger.warning(f"Failed to read file/sheet: {damage_csv_file} -- {e}")
                        continue

                    damage_gather_sa = np.asarray(damage_gather_sa)
                    if damage_gather_sa.size == 0:
                        continue

                    exist_type.append([
                        f"{str_type}_{building_function}_{epa}_{rise_category}",
                        int(np.max(damage_gather_sa))
                    ])

                    # Fit for each damage state
                    num_gms = np.max(damage_gather_sa, axis=1)
                    damage_state_gather = list(df['damage_grade'])
                    mu_ln_map = {}
                    sigma_ln_map = {}
                    fragility_paras_ = []
                    num_collapse_stat = damage_gather_sa  # shape: (len(sf_list), n_states)

                    for idx, damage_state in enumerate(damage_state_gather):
                        col = damage_gather_sa[:, idx]
                        if np.all(col == np.max(damage_gather_sa, axis=1)):
                            # All exceed (or identical to total) -> set to zeros as sentinel
                            mu_ln_map[damage_state], sigma_ln_map[damage_state] = 0.0, 0.0
                        elif np.sum(col) == 0:
                            # No exceedance at all -> set to zeros as sentinel
                            mu_ln_map[damage_state], sigma_ln_map[damage_state] = 0.0, 0.0
                        else:
                            mu, sigma = cal_fragility(
                                np.array(sa_readable),
                                np.array(num_gms),
                                col,
                                show_fig=show_fig
                            )
                            mu_ln_map[damage_state], sigma_ln_map[damage_state] = mu, sigma
                            if np.isnan(mu):
                                logger.warning(
                                    f"Unable to fit damage state {damage_state} in file {damage_csv_file.name}"
                                )

                        fragility_paras_.extend([
                            mu_ln_map[damage_state],
                            sigma_ln_map[damage_state]
                        ])

                    # Evaluate fitted curves and save plots/CSV
                    Sa_fit = np.linspace(0.01, 2.0, 100)
                    # cal_p_collapse expects log(Sa_fit)
                    p_list = []
                    for damage_state in damage_state_gather:
                        p_list.append(
                            cal_p_collapse(
                                np.log(Sa_fit),
                                mu_ln_map[damage_state],
                                sigma_ln_map[damage_state]
                            )
                        )

                    save_name = f"{str_type}_{building_function}_{epa}_{rise_category}"
                    plot_fragility_curves(
                        Sa_fit, p_list, path_save, save_name, np.array(sa_readable),
                        damage_state_gather, num_collapse_stat, num_gms,
                        show_state0=False, show_fig=show_fig, save_scatter_value=True
                    )

                    fragility_paras_all.append(fragility_paras_)

    # Aggregate to Excel
    if len(fragility_paras_all) > 0:
        fragility_paras_arr = np.asarray(fragility_paras_all, dtype=object)
        exist_arr = np.asarray(exist_type, dtype=object)
        save_gather = np.concatenate((exist_arr, fragility_paras_arr), axis=1)
        columns = [
            'type', 'num_of_buildings',
            'DS1_log_mean', 'DS1_log_std',
            'DS2_log_mean', 'DS2_log_std',
            'DS3_log_mean', 'DS3_log_std',
            'DS4_log_mean', 'DS4_log_std',
            'DS5_log_mean', 'DS5_log_std'
        ]
        df_out = pd.DataFrame(save_gather, columns=columns)
        out_file = out_dir / "fragility_paras" / f"{city}_fragility_paras.xlsx"
        df_out.to_excel(out_file, index=False)
        logger.info(f"Wrote fragility parameters: {out_file}")
    else:
        logger.info(f"No fragility parameters generated for city {city} (no matching input files).")



def parse_args():
    """Parse command-line arguments."""
    p = argparse.ArgumentParser(description="Fit fragility curves batch processor")
    p.add_argument("--data_path", "-d", type=str, required=True, help="Root directory containing input Excel files")
    p.add_argument("--out_path", "-o", type=str, default="output", help="Root directory for outputs")
    p.add_argument("--cities", "-c", type=str, nargs="+", required=True, help="List of city codes (e.g., 110000 120000)")
    p.add_argument("--str_types", type=str, nargs="+", default=['bc','rc','wd'], help="Structural type abbreviations")
    p.add_argument("--functions", type=str, nargs="+", default=['r','b','p','i','o','x'], help="Building function codes")
    p.add_argument("--epa", type=str, nargs="+", default=['0.05','0.1','0.15','0.2','0.3','0.4','0.5'], help="EPA list")
    p.add_argument("--sfs", type=float, nargs="+", default=[0.025,0.05,0.075,0.1,0.2,0.3,0.5,0.8,1.0,1.5], help="PGA list")
    p.add_argument("--rise_cats", type=str, nargs="+", default=['h5'], help="Rise category list")
    p.add_argument("--show_fig", action="store_true", help="Display figures in real time")
    p.add_argument("--debug", action="store_true", help="Enable debug logging")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    if args.debug:
        logger.setLevel(logging.DEBUG)

    data_path = Path(args.data_path)
    out_path = Path(args.out_path)
    (out_path / "fragility_paras").mkdir(parents=True, exist_ok=True)
    for city in args.cities:
        logger.info(f"Processing city {city} ...")
        process_city(data_path, city, args.str_types, args.functions, args.epa,
                     args.sfs, args.rise_cats, out_path, show_fig=args.show_fig)
    logger.info("All processing completed.")
