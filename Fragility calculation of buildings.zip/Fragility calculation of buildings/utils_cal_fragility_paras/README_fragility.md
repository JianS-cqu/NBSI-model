# Fragility Curve Fitting — Nationwide Building Fragility Assessment

## Overview
This folder provides code for fitting fragility curves of building clusters from batch Excel outputs, where each sheet corresponds to one PGA (Sa) level.  
The folder performs Probit regression in the log(Sa) domain, outputs the fitted lognormal parameters (`mu_ln`, `sigma_ln`), and generates fragility curve plots together with scatter data.  
The repository is intended for open distribution alongside academic publications as supporting code.

---

## Dependencies
Install the required packages via:

```bash
pip install -r requirements.txt
```


## Example usage

Assuming the input Excel files are located in /sample_data/, run:


python fit_fragility_curve.py --data_path ./sample_data --out_path  ./output_fragility_paras  --cities 450000   --str_types bc   --functions b   --epa 0.1 --rise_cats h2   --sfs 0.025 0.05 0.075 0.1 0.2 0.3 0.5 0.8 1.0 1.5



## Input file format

### File naming convention

damage_grade_total_count_city{110000}_str_type_simple{bc}_building_function{r}_epa{0.05}_rise_category{h5}.xlsx


### Output

output/fragility_paras/{city}/{save_name}.png: Fragility curve plots for all damage states.

output/fragility_paras/{city}/{save_name}_scatter/{save_name}.png: Fragility curves with scatter points.

output/fragility_paras/{city}/{save_name}_scatter/{save_name}.csv: Numerical scatter values (for reproducibility and re-plotting).

output/fragility_paras/{city}_fragility_paras.xlsx: Summary of fitted fragility parameters (each row corresponds to one structural case).