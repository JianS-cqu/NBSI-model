# Basic Description 

The programs in this folder are designed to support **urban building cluster analysis**, including  
- building information preprocessing,  
- automated modeling of buildings,  
- parallel seismic response calculation,  
- structural damage assessment, and  
- fragility curve fitting.  

It consists of the following files and directories:

---

### `data_bulidings_raw`
Directory containing the **raw building data** of urban clusters, obtained from remote sensing or other sources.  

---

### `Recommended Ground Motion`
Directory containing the **ground motion records**.  

---

### `data_bulidings_prepared`
Directory containing **preprocessed building cluster data**, including both building information and ground motion data.  

---

### `data_preparation.ipynb`
Jupyter Notebook script for **data preprocessing**.  

---

### `response calculation`
Directory for **seismic response analysis** of building clusters, including:  
- `parallel_computering.py`: main script for parallel computation  
- `model-shear-SDOF.tcl` and `model-shear.tcl`: structural modeling subroutines  
- `seismicity.tcl`: finite element time-history analysis subroutine  
- `Structural damage assessment.py`: structural damage identification program  

---

### `utils_cal_fragility_paras`
Directory containing the program for **fragility curve fitting** based on structural seismic response results.  
For usage instructions, refer to the included `README_fragility.md`.  
