import numpy as np
import pandas as pd
import os
#refer:https://www.fema.gov/sites/default/files/2020-09/fema_hazus_earthquake-model_technical-manual_2.1.pdf
def damage_grade_count(str_type,numStory,desn,EnvelopeDrift_max):
    # if desn == 'P':'0.025','0.05'
    if desn == '0.025' or '0.05':
        if str_type == 1:
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0064, 0.0160, 0.0400,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0027, 0.0043, 0.0107, 0.0267,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0020, 0.0032, 0.0080, 0.0200,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 2 or str_type == 3:
            if numStory<=3:
                bins = [-1e10000, 0.0032, 0.0061, 0.0158, 0.0400,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0021, 0.0041, 0.0105, 0.0105,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0016, 0.0031, 0.0079, 0.0200,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 4:
            if numStory<=2:
                bins = [-1e10000, 0.0024, 0.0048, 0.0120, 0.02800,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else :
                bins = [-1e10000, 0.0016, 0.0032, 0.080, 0.0080,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 5:
            if numStory<=3:
                bins = [-1e10000, 0.0032, 0.0051, 0.0128, 0.03500,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0021, 0.0034, 0.0086, 0.0233,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)  
        elif str_type == 7 :
            if numStory<=3:
                bins = [-1e10000, 0.0048, 0.0076, 0.0162, 0.0400,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0032, 0.0051, 0.0108, 0.0267,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0024, 0.0038, 0.0081, 0.0200,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)  
        elif str_type == 8 :
            bins = [-1e10000, 0.0032, 0.0079, 0.0245, 0.0600,1e10000]  
            hist, bin_edges = np.histogram(EnvelopeDrift_max, bins) 
        elif str_type == 9 :
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0064, 0.0160, 0.0400,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0027, 0.0043, 0.0107, 0.0267,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0020, 0.0032, 0.0080, 0.0200,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
    
    # elif desn == 'L':
    elif desn == '0.1' or '0.15':
        if str_type == 1:
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0064, 0.0160, 0.0400,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0027, 0.0043, 0.0107, 0.0267,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0020, 0.0032, 0.0080, 0.0200,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 2 or str_type == 3:
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0076, 0.0197, 0.0500,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0027, 0.0051, 0.0132, 0.0333,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0020, 0.0038, 0.0099, 0.0250,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 4:
            if numStory<=2:
                bins = [-1e10000, 0.0030, 0.0060, 0.0150, 0.0350,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.002, 0.004, 0.01, 0.0233,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 5:
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0064, 0.0161, 0.0438,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0027, 0.0043, 0.0107, 0.0292,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins) 
        elif str_type == 7 :
            if numStory<=3:
                bins = [-1e10000, 0.0060, 0.0096, 0.0203, 0.0500,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.004, 0.0064, 0.0135, 0.0333,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.003, 0.0048, 0.0101, 0.0250,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)  
        elif str_type == 8 :
            bins = [-1e10000, 0.0040, 0.0099, 0.0306, 0.0750,1e10000]  
            hist, bin_edges = np.histogram(EnvelopeDrift_max, bins) 
        elif str_type == 9 :
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0064, 0.0160, 0.0400,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0027, 0.0043, 0.0107, 0.0267,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0020, 0.0032, 0.0080, 0.0200,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)       
    # elif desn == 'M': '0.2','0.3'
    elif desn == '0.2' or '0.3':
        if str_type == 1:
            if numStory<=3:
                bins = [-1e10000, 0.0050, 0.0087, 0.0233, 0.0600,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0033, 0.0058, 0.0156, 0.0400,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0025, 0.0043, 0.0117, 0.0300,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 2 or str_type == 3:
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0084, 0.0232, 0.0600,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0027, 0.0056, 0.0154, 0.0400,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0020, 0.0042, 0.0116, 0.0300,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 4 or str_type == 5:
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0069, 0.0187, 0.0525,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else :
                bins = [-1e10000, 0.0027, 0.0046, 0.0125, 0.0350,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 7 :
            if numStory<=3:
                bins = [-1e10000, 0.0060, 0.0104, 0.0235, 0.0600,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.004, 0.0069, 0.0157, 0.0400,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.003, 0.0052, 0.0118, 0.0300,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)  
        elif str_type == 8 :
            bins = [-1e10000, 0.0040, 0.0099, 0.0306, 0.0750,1e10000]  
            hist, bin_edges = np.histogram(EnvelopeDrift_max, bins) 
        elif str_type == 9 :
            if numStory<=3:
                bins = [-1e10000, 0.0050, 0.0087, 0.0233, 0.0600,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0033, 0.0058, 0.0156, 0.0400,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0025, 0.0043, 0.0117, 0.0300,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
    # elif desn == "H":
    elif desn == '0.4' or '0.5':
        if str_type == 1:
            if numStory<=3:
                bins = [-1e10000, 0.0050, 0.0100, 0.0300, 0.0800,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0033, 0.0067, 0.0200, 0.0533,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0025, 0.0050, 0.0150, 0.0400,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 2 or str_type == 3:
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0100, 0.0300, 0.0800,1e10000] 
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0027, 0.0067, 0.0200, 0.0533,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0020, 0.0050, 0.0150, 0.0400,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 4 or str_type == 5:
            if numStory<=3:
                bins = [-1e10000, 0.0040, 0.0080, 0.0240, 0.0700,1e10000] 
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else :
                bins = [-1e10000, 0.0027, 0.0053, 0.0160, 0.0467,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
        elif str_type == 7 :
            if numStory<=3:
                bins = [-1e10000, 0.0060, 0.0120, 0.0300, 0.0800,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.004, 0.0080, 0.0200, 0.0533,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.003, 0.0060, 0.0150, 0.0400,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)  
        elif str_type == 8 :
            bins = [-1e10000, 0.0040, 0.0120, 0.0400, 0.1000,1e10000]  
            hist, bin_edges = np.histogram(EnvelopeDrift_max, bins) 
        elif str_type == 9 :
            if numStory<=3:
                bins = [-1e10000, 0.0050, 0.0100, 0.0300, 0.0800,1e10000]  
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            elif numStory<=7:
                bins = [-1e10000, 0.0033, 0.0067, 0.0200, 0.0533,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
            else:
                bins = [-1e10000, 0.0025, 0.0050, 0.0150, 0.0400,1e10000]
                hist, bin_edges = np.histogram(EnvelopeDrift_max, bins)
    return hist

def get_damage_grade(str_type,numStory,desn,EnvelopeDrift_max):
    num_structure = EnvelopeDrift_max.shape[0]
    for i in range(num_structure):
        damage_grade = damage_grade_count(str_type[i],numStory[i],desn[i],EnvelopeDrift_max[i])
        indices_grade = np.where(damage_grade == 1) # damage state:0(negligible),1(slight),2(moderate),3(extensive),4(comlete)
        if i == 0:
            indices_grade_total = indices_grade
        else :
            indices_grade_total = np.append(indices_grade_total,indices_grade)
    return indices_grade_total

# 结构响应及结构信息的跟目录
path_root = os.path.split(os.path.realpath(__file__))[0] # Get the current file path
path_root = path_root.replace('\\', '/') 
path = os.path.join(path_root, 'data_buildings_prepared') # directory for structural responses and structural information.
path = path.replace('\\', '/') 
city_list = ['500000']
str_type_simple_list = ['rc'] # ['bc','rc','wd']
building_function_list = ['r','b','p','i','o','x'] # ['r','b','p','i','o','x'] Building function
epa_list = ['0.05','0.1','0.15','0.2','0.3','0.4','0.5'] # Design basic acceleration
rise_category_list = ['h1','h2','h3','h4','h5'] # ['h1','h2','h3','h4','h5'
sf_list = [0.025,0.05,0.075,0.1,0.2,0.3,0.5,0.8,1.0,1.5] # Amplification factor    0.025*g,0.05*g,0.075*g,0.1*g,0.2*g,0.3*g,0.5*g,0.8*g,1.0*g,1.5*g 

for city in  city_list:
    for str_type_simple in  str_type_simple_list:
        for building_function in  building_function_list:
            for epa in  epa_list:
                for rise_category in rise_category_list:
                    for sf in sf_list:
                        parameters_csv_file = os.path.join(path,f'{city}',f'city{{{city}}}_str_type_simple{{{str_type_simple}}}_building_function{{{building_function}}}_epa{{{epa}}}_rise_category{{{rise_category}}}_ScaleFactor{{{sf}}}.csv')
                        
                        if os.path.exists(parameters_csv_file):
                            print("文件存在",parameters_csv_file)
                            df_parameters = pd.read_csv(parameters_csv_file, sep=',')
                            
                            # Extract building data for different cities, structural types (timber-masonry, reinforced masonry, steel-reinforced concrete), seismic design levels (PC/LC/MC/HC), and height categories.
                            # The extracted data are used for damage assessment (including structural type, number of stories, and seismic design level; the design seismic intensity is not used because structures of the same intensity in different years correspond to different seismic levels in the US code).
                            
                            if df_parameters.shape[0] == 0:
                                continue
                            str_type = df_parameters['str_type']
                            numStory = df_parameters['numStory']
                            desn = pd.DataFrame([epa] * numStory.shape[0], columns=['desn'])
                            desn = desn['desn']
                            EnvelopeDrift_max_file_path = os.path.join(path,f'{city}',f'EnvelopeDrift_max_total_city{{{city}}}_str_type_simple{{{str_type_simple}}}_building_function{{{building_function}}}_epa{{{epa}}}_rise_category{{{rise_category}}}_ScaleFactor{{{sf}}}.npy')
                            EnvelopeDrift_max = (np.load(EnvelopeDrift_max_file_path))[:df_parameters.shape[0],1] # Since the parallel program initially computes extra data, only df_parameters.shape[0] responses are needed here.
                            
                            num_structure = EnvelopeDrift_max.shape[0]
                            indices_grade_total = get_damage_grade(str_type,numStory,desn,EnvelopeDrift_max)
                            # count the num of damage grade
                            bins = [0, 1, 2, 3, 4, 5]
                            hist, bin_edges = np.histogram(indices_grade_total, bins)
                            num_negligible = hist[0]
                            num_slight = hist[1]
                            num_moderate = hist[2]
                            num_extensive = hist[3]
                            num_comlete = hist[4]
                            damage_grade_output = [['negligible',num_negligible,f"{num_negligible/num_structure:.2%}"],
                                                ['slight',num_slight,f"{num_slight/num_structure:.2%}"],
                                                ['moderate',num_moderate,f"{num_moderate/num_structure:.2%}"],
                                                ['extensive',num_extensive,f"{num_extensive/num_structure:.2%}"],
                                                ['complete',num_comlete,f"{num_comlete/num_structure:.2%}"],
                                                ['sum',num_structure,f"{num_structure/num_structure:.2%}"]]
                            grade_total_count = pd.DataFrame(damage_grade_output,columns=['Damage Grade','Number','Proportion'])
                            # Save the damage grade statistics results
                            damage_grade_total_count = os.path.join(path,f'{city}',f'damage_grade_total_count_city{{{city}}}_str_type_simple{{{str_type_simple}}}_building_function{{{building_function}}}_epa{{{epa}}}_rise_category{{{rise_category}}}.xlsx')
                            if sf == sf_list[0]:
                                writer = pd.ExcelWriter(damage_grade_total_count)
                            grade_total_count.to_excel(writer, f'grade_total_count_{sf}g')
                            if sf == sf_list[-1]:
                                writer._save()
                                writer.close()  
                        else:
                            print("File does not exist:",parameters_csv_file)
                            continue             
    print(f"the percentage of damage state of {city} is calculated")