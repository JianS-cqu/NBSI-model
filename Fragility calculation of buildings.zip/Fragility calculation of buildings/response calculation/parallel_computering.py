import math
import os
import subprocess
import numpy as np
import pandas as pd
from multiprocessing import Pool
import concurrent.futures
import shutil

execute_part1 = True
execute_part2 = True
execute_part3 = True

city_list = ['500000']
str_type_simple_list = ['bc','rc','wd'] # ['bc','rc','wd'] 
building_function_list =['r','b','p','i','o','x'] # ['r','b','p','i','o','x'] Building function
epa_list = ['0.05','0.1','0.15','0.2','0.3','0.4','0.5'] #['0.025','0.05','0.1','0.15','0.2','0.3','0.4','0.5'] Design basic acceleration
rise_category_list = ['h5'] # ['h1','h2','h3','h4','h5']
sf_list = [0.025,0.05,0.075,0.1,0.2,0.3,0.5,0.8,1.0,1.5] #  Amplification factor  0.025*g,0.05*g,0.075*g,0.1*g,0.2*g,0.3*g,0.5*g,0.8*g,1.0*g,1.5*g 

for city in  city_list:
    for str_type_simple in  str_type_simple_list:
        for building_function in  building_function_list:
            for epa in  epa_list:
                for rise_category in rise_category_list:
                    for sf in sf_list:
                        path = os.path.split(os.path.realpath(__file__))[0]
                        path = path.replace('\\', '/') # Replace backslashes with forward slashes for compatibility
                        parameters_csv_file = os.path.join(path,f'data_bulidings_prepared',f'{city}',f'city{{{city}}}_str_type_simple{{{str_type_simple}}}_building_function{{{building_function}}}_epa{{{epa}}}_rise_category{{{rise_category}}}_ScaleFactor{{{sf}}}.csv')
                        npy_file_path = os.path.join(path,'data_bulidings_prepared',f'{city}',f'EnvelopeDrift_max_total_city{{{city}}}_str_type_simple{{{str_type_simple}}}_building_function{{{building_function}}}_epa{{{epa}}}_rise_category{{{rise_category}}}_ScaleFactor{{{sf}}}.npy')

                        if os.path.exists(npy_file_path):
                            print(f"{npy_file_path} file exists",npy_file_path)
                            continue  
                        if os.path.exists(parameters_csv_file):
                            print("file exists",parameters_csv_file)
                            if execute_part1:
                                print("Executing Part 1")
                                # Part 1 code
                                df_parameters = pd.read_csv(parameters_csv_file, sep=',')
                                ##########################################################################
                                min_str = df_parameters.iloc[0,0]; # the minimum structure ID.（"parameters.txt"的第一列）
                                max_str = df_parameters.iloc[-1,0] ; # the maximum structure ID.（"parameters.txt"的第一列）
                                sample_parallel_max = 10000 # maximum number of structures for each parallel program
                                circle =  math.ceil((max_str-min_str+1)/sample_parallel_max)  
                                kernel = 15 # kernel: The number of cores to use; around 70% of CPU cores is recommended
                                
                                
                                ###########################################################################
                                
                                num_parallel_computing = kernel*circle    #  Number of generated TCL files
                                total_sample = max_str - min_str + 1
                                block_size = math.ceil(total_sample/num_parallel_computing) 
                                block_num = num_parallel_computing
                                
                                # To avoid read congestion, modeling and analysis files are copied num_parallel_computing times, renamed accordingly, and later used in the combined TCL file.
                                source_filename_list = ['model-flexible-shear.tcl','model-masonry.tcl','model-masonry-SDOF.tcl','model-shear.tcl','model-shear-SDOF.tcl','model-Steel-frame-shear.tcl','model-Steel-frame-shear-SDOF.tcl','model-wooden-house.tcl','model-wooden-house-SDOF.tcl','seismicity.tcl','seismicity_flexible_shear.tcl','SmartAnalyze.tcl']
                                has_copied = False
                                if not has_copied:
                                    for source_filename_i in source_filename_list:
                                        for num_parallel_computing_i in range(1,num_parallel_computing+1):
                                            base_name,extension = os.path.splitext(source_filename_i)
                                            new_filename = f'{base_name}_{num_parallel_computing_i}{extension}'
                                            shutil.copy(os.path.join(path,source_filename_i), os.path.join(path,new_filename)) 
                                    has_copied = True  # Set the flag to True after copying

                                # Create temporary_output directory
                                path_output = os.path.join(path,'temporary_output')
                                if not os.path.exists(path_output):
                                    os.mkdir(path_output)
                                    
                                for i in range(1,block_num+1):
                                    filename_parameters_txt = os.path.join(path,f'./{i}.tcl')
                                    f1 = open(filename_parameters_txt,'w')
                                    f1.close()
                                    begin_str = min_str + (i-1)*block_size ; # In each parallel process, the minimum structure identifier is calculated.
                                    end_str   = begin_str + block_size -1; # In each parallel process, the maximum structure identifier is calculated.
                                    if i == block_num:
                                        end_str = max_str

                                    # Split parameters into parts, matching the number of TCL files.
                                    parameters_i = df_parameters[begin_str-1:end_str].astype(str)
                                    filename_parameters_i = os.path.join(path,f'parameters{i}.txt')
                                    parameters_i.to_csv(filename_parameters_i, sep=' ', index=False, header=False)

                                    # Generate TCL subfiles.
                                    with open(filename_parameters_txt, 'w', encoding='utf-8') as f2:
                                        f2.write(f"""
# Main program logic:
# 1. Parameter reading: First, the parameter file "parameters.txt" is read, which contains structural parameters, site parameters, and ground motion parameters.
# 2. Structural modeling: Based on the parameter file "parameters.txt", the skeleton lines and hysteretic characteristics of each layer of the structure are estimated, and a multi-degree-of-freedom model of the structure is automatically established.
# 3. Data recording: Mainly used to record structural responses.
# 4. Structural deformation display.
# 5. Seismic response analysis: According to the ground motion information in the parameter file "parameters.txt", the ground motion files in the "Ground_motion_Data" folder are read, and convergence criteria, iterative algorithms, etc. are set for seismic response calculation.

wipe
# define basic units
set g  9.8
set m 1.;
set sec 1.;
set N 1.;
set LunitTXT "m";			# define basic-unit text for temporary_output
set FunitTXT "N";			  # define basic-unit text for temporary_output
set TunitTXT "sec";			  # define basic-unit text for temporary_output
############################################################################################################################################################################################################
########————1. Parameter reading: First, the parameter file "parameters.txt" is read, which contains structural parameters, site parameters, and ground motion parameters.—————————————————————————#########
############################################################################################################################################################################################################
# Create a new temporary_output file.
set  fDir1    "temporary_output"
file mkdir     $fDir1
set chan1 [open "{path}/parameters{i}.txt" r]; 

set str_param_file "temporary_output/=str_param.txt";
set chan2 [open $str_param_file a]; 
set num_str 0; # num_str: counter for structure number
set begin_str {begin_str}; # The minimum structure ID to be calculated.
set end_str   {end_str}; # The maximum structure ID to be calculated.
while {{[gets $chan1 parameters_str]>=0}} {{
    set name_str         [lindex $parameters_str 0];
    if {{ $name_str >= $begin_str }} {{
            # Control the starting index of structures to be computed.
            if {{$name_str > $end_str}} {{
                # Control the ending index of structures to be computed.
                break
            }}   
            incr num_str;
            set numStory        [lindex $parameters_str 1];
            set Fstorey_height   [lindex $parameters_str 2];
            set storey_height    [lindex $parameters_str 3];
            set length           [lindex $parameters_str 4];
            set breadth          [lindex $parameters_str 5];
            set str_type         [lindex $parameters_str 6];
            set site_class       [lindex $parameters_str 7];
            set seismic_class    [lindex $parameters_str 8];
            set DI               [lindex $parameters_str 9];
            set DGA              [expr [lindex $parameters_str 10]*$g];
            
            set ratio_k_yield           0.7;
            set iGMfile          "{path}/Ground_motion_Data/[lindex $parameters_str 11]";
            set iGMfact          [expr 1*[lindex $parameters_str 12]*$g];
            set dt               [lindex $parameters_str 13];
            set npts             [lindex $parameters_str 14];
            
            set buildYear        [lindex $parameters_str 15];
            set tg               [lindex $parameters_str 16];
            
            set T(1)             [lindex $parameters_str 17];
            set T(2)             [lindex $parameters_str 18];
            set display_or_not          [lindex $parameters_str 19]; # Whether to visualize (0: No, 1: Yes).
            
            set area    [expr $length*$breadth];
            set total_height  [expr $Fstorey_height+($numStory-1)*$storey_height]	; 
            
            # set rofB [expr 15*1000*$breadth*$length/3.0/$g]	; #kg/m, Assume a story height of 3 m. Frame structures: 11～14KN/㎡;
            if {{ $str_type == 1 }} {{
                set rofB [expr 12.5*1.e3*$breadth*$length/3/$g]	;# Frame structure
            }} elseif {{ $str_type == 9 }} {{
                set rofB [expr 12.5*1.e3*$breadth*$length/3/$g]	;# Other
            }}
            set PointMass [expr $rofB*$storey_height]		;# N
            
            if {{$T(1) == ""}} {{
                # Period estimation
                if {{ $str_type == 1 }} {{
                    set T(1) [expr 0.25+0.00053*pow($total_height,2)/pow($breadth,1/3.0)]			; # Load standard GB 50009-2012
                }} elseif {{ $str_type == 9 }} {{
                    set T(1) [expr 0.075*$numStory]	; # Others are treated uniformly as concrete frame structures (all single-story, story height below 3.75 m).
                }}  
            }}
            
            set PI [expr acos(-1.0)] 	;   # set PI [expr 2*asin(1.0)]
            set w(1) [expr 2*$PI/$T(1)];
            
            
            ####################################################################################################################################################################################################################
            ########—————2. Structural modeling: the skeleton lines and hysteretic characteristics of each layer of the structure are estimated, and a MDOF model of the structure is automatically established.———————#########
            ####################################################################################################################################################################################################################
            # To reflect differences in seismic standards across construction years, reductions are applied to the structural backbone curves.
            if {{ $buildYear < 1978 }} {{
                if {{ $DI <= 7 }} {{            
                        set eta_F 0.50
                        set eta_d 0.80
                }} elseif {{ $DI <= 8 }} {{
                        set eta_F 0.50
                        set eta_d 0.67
                }} else {{
                        set eta_F 0.25
                        set eta_d 0.5
                }}                  
            }} elseif {{ 1978 <= $buildYear <= 1989 }} {{
                if {{ $DI <= 7 }} {{            
                        set eta_F 0.50
                        set eta_d 0.83
                }} elseif {{ $DI <= 8 }} {{
                        set eta_F 0.50
                        set eta_d 0.83
                }} else {{
                        set eta_F 0.50
                        set eta_d 0.75
                }}   
            }} elseif {{ 1989 < $buildYear }} {{
                if {{ $DI <= 7 }} {{            
                        set eta_F 1.00
                        set eta_d 1.00
                }} elseif {{ $DI <= 8 }} {{
                        set eta_F 1.00
                        set eta_d 1.00
                }} else {{
                        set eta_F 1.00
                        set eta_d 1.00
                }}   
            }}                 
                
            
            if {{ $str_type == 1 }} {{
                if {{ $numStory == 1 }} {{   ; # Frame structure
                        source {{{path}\model-shear-SDOF_{i}.tcl}}
                }} else {{
                        source {{{path}\model-shear_{i}.tcl}}
                }}                
            }} elseif {{ $str_type == 9 }} {{ 
                # Other, unified as concrete frame structure (all one-story structures, with a story height of less than 3.75m)
                if {{ $numStory == 1 }} {{            
                        source  {{{path}\model-shear-SDOF_{i}.tcl}}
                }} else {{
                        source {{{path}\model-shear_{i}.tcl}}
                }}
            }}
            # After running source model.tcl, the basic parameters may change. The following restores the original values.
            set name_str         [lindex $parameters_str 0];
            set numStory        [lindex $parameters_str 1];
            set Fstorey_height   [lindex $parameters_str 2];
            set storey_height    [lindex $parameters_str 3];
            set length           [lindex $parameters_str 4];
            set breadth          [lindex $parameters_str 5];
            set str_type         [lindex $parameters_str 6];
            set site_class       [lindex $parameters_str 7];
            set seismic_class    [lindex $parameters_str 8];
            set DI               [lindex $parameters_str 9];
            set DGA              [expr [lindex $parameters_str 10]*$g];
            # puts "base_information_inputing $name_str ok"
            
            ######################################################################################################
            ########—————————————Data recording: Mainly used to record structural responses.—————————————#########
            ######################################################################################################
            # timeSeries Path $tag -dt $dt -filePath $filePath <-factor $cFactor>
            if {{ $str_type == 1 }} {{
                # Unreinforced masonry (URM), Reinforced masonry (RM), Reinforced concrete frame (RCF), Single-story frame (SSF), Steel structure (SS), Timber structure (TS), Others
                timeSeries Path 1 -dt $dt -filePath $iGMfile -factor $iGMfact;  # define acceleration vector from file (dt=0.01 is associated with the input file gm)
                recorder EnvelopeDrift -file {path}/temporary_output/structure$name_str=EnvelopeDrift.txt  -iNode   0  1  2  3  4  5  6  7  8  9  10  11  12  13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29  30 31 32 33 34 35 36 37 38 39  -jNode  1  2  3  4  5  6  7  8  9  10  11  12  13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40  -dof 1 -perpDirn 2 ;

            }} 
            ######################################################################################################
            ########—————————————————————4. Structural deformation display———————————————————————————————#########
            ######################################################################################################
            # # display displacement shape of the columns
            if {{ $display_or_not == 1 }} {{
                recorder display "Displaced shape structure:$num_str" 10 10 500 500 -wipe
                prp 200. 50. 1;
                vup  0  1 0;
                vpn  0  0 1;
                display 1 5 40 
            }} 
            
            ######################################################################################################
            ########—————————————————5. Seismic response calculation—————————————————————————————————————#########
            ######################################################################################################
            # Ground motion input
            source {{{path}\SmartAnalyze_{i}.tcl}} 
            if {{ $str_type == 1 }} {{
                source {{{path}\seismicity_{i}.tcl}}                    ; 
            }} elseif {{ $str_type == 9 }} {{             
                source {{{path}/seismicity_{i}.tcl}}	                  ; # Others, unified as concrete frame structure (all single-story structures with a height of less than 3.75m)
            }} 

            wipe
    }}   
}}
close $chan1; 
close $chan2; 

                                    """)
                                del df_parameters

                            if execute_part2:
                                print("Executing Part 2")
                                all_envelope_data = []
                                # Parallel files (smart method), calculated based on the number of generated TCL files.
                                opensees_path = os.path.join(path,'OpenSees.exe')
                                num_output_sample = 0
                                for circle_i in range(1,circle+1):
                                    tcl_file_paths = [os.path.abspath(f'{path}/{i}.tcl') for i in range(1+(circle_i-1)*kernel,circle_i*kernel+1)]

                                    # Define a function to run the OpenSees process.
                                    def run_opensees(tcl_file_path):
                                        process = subprocess.Popen([opensees_path, tcl_file_path])
                                        process.wait()
                                        return f"Completed: {tcl_file_path}"

                                    # Use ThreadPoolExecutor to run OpenSees in parallel.
                                    with concurrent.futures.ThreadPoolExecutor(max_workers=kernel) as executor:
                                        results = list(executor.map(run_opensees, tcl_file_paths))

                                    # Process temporary_output data
                                    path_output = os.path.join(path, 'temporary_output')
                                    for output_i in range(min_str + (circle_i - 1) * kernel * block_size, min_str + circle_i * kernel * block_size + 1):
                                        file_EnvelopeDrift = os.path.join(path_output, f"structure{output_i}=EnvelopeDrift.txt")
                                        if os.path.exists(file_EnvelopeDrift):
                                            EnvelopeDrift = (np.loadtxt(file_EnvelopeDrift)).reshape(3, -1)[-1, :]
                                            EnvelopeDrift_max = max(EnvelopeDrift)
                                            os.remove(file_EnvelopeDrift)
                                            all_envelope_data.append([output_i, EnvelopeDrift_max])

                            if execute_part3:
                                print("Executing Part 3")
                                data = np.array(all_envelope_data)
                                npy_file_path = os.path.join(path, 'data_bulidings_prepared', f'{city}', 
                                                            f'EnvelopeDrift_max_total_city{{{city}}}_str_type_simple{{{str_type_simple}}}_building_function{{{building_function}}}_epa{{{epa}}}_rise_category{{{rise_category}}}_ScaleFactor{{{sf}}}.npy')
                                np.save(npy_file_path, data)
                                
                            else:
                                print("File does not exist:", parameters_csv_file)